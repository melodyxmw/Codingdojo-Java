public class FirstJavaProgram {
    public static void main(String[] args) {
        System.out.println("My name is Coding Dojo \nI am 100 years old \nMy hometown is Burbank, CA");
    }
}
